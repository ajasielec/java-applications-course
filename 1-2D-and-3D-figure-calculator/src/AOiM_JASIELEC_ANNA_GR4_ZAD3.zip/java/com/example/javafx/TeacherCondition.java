package com.example.javafx;

public enum TeacherCondition {
    present, delegation, sick, absent;
}
