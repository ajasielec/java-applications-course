public interface Printing {
    public String print();
}
