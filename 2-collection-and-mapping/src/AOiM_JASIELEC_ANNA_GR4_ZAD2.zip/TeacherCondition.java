public enum TeacherCondition {
    present, delegation, sick, absent;
}
